
package parcial2caso.Modelo;


public interface CSVSerializable {
    String toCSV();
}
